WITH AvionesEnAeropuertos AS (
    -- Recopila todos los aviones que han estado en cada aeropuerto (tanto salidas como llegadas)
    SELECT v.aeropuertoSalida AS codigo_aeropuerto, v.avion, a.agnoFabricacion
    FROM VUELO v
    JOIN AVION a ON v.avion = a.matricula
    UNION
    SELECT v.aeropuertoLlegada AS codigo_aeropuerto, v.avion, a.agnoFabricacion
    FROM VUELO v
    JOIN AVION a ON v.avion = a.matricula
),
EdadPromedioPorAeropuerto AS (
    -- Calcula la edad promedio de los aviones para cada aeropuerto
    SELECT codigo_aeropuerto, AVG(EXTRACT(YEAR FROM SYSDATE) - agnoFabricacion) AS edad_promedio
    FROM AvionesEnAeropuertos
    GROUP BY codigo_aeropuerto
),
AeropuertoConAvionesJovenes AS (
    -- Filtra solo los aeropuertos con la menor edad promedio (los mas nuevos)
    SELECT codigo_aeropuerto, edad_promedio
    FROM EdadPromedioPorAeropuerto
    WHERE edad_promedio = (SELECT MIN(edad_promedio) FROM EdadPromedioPorAeropuerto)
)
SELECT a.IATA, a.nombre, aaj.edad_promedio AS media_edad_aviones
FROM AeropuertoConAvionesJovenes aaj
JOIN AEROPUERTO a ON aaj.codigo_aeropuerto = a.IATA;